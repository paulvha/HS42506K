/*
 * supports display on HS420561K-32
 *
 * version 1.0 / paulvha / march 2016
 *
 * see hs42led.h for details
 *
 *
 * ***************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 ***************************************************************************
 *
 * This version of GPL is at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 *
 ***************************************************************************
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>
#include "timer.h"
#include "hs42led.h"
#include <time.h>
#include <termios.h>
#include <unistd.h>

#ifdef _wiring
#include <wiringPi.h>
#else
#include "bcm2835.h"
#endif


/* Common Cathode overview of characters to display */
int disp_char [77][8]=
{
    {'0',1,1,1,1,1,1,0},
    {'1',0,1,1,0,0,0,0},
    {'2',1,1,0,1,1,0,1},
    {'3',1,1,1,1,0,0,1},
    {'4',0,1,1,0,0,1,1},
    {'5',1,0,1,1,0,1,1},
    {'6',1,0,1,1,1,1,1},
    {'7',1,1,1,0,0,0,0},
    {'8',1,1,1,1,1,1,1},
    {'9',1,1,1,0,0,1,1},
    {'a',1,1,1,1,1,0,1},
    {'b',0,0,1,1,1,1,1},
    {'c',0,0,0,1,1,0,1},
    {'d',0,1,1,1,1,0,1},
    {'e',1,1,0,1,1,1,1},
    {'f',1,0,0,0,1,1,1},
    {'g',1,1,1,1,0,1,1},
    {'h',0,0,1,0,1,1,1},
    {'i',0,1,1,0,0,0,0},
    {'j',0,1,1,1,0,0,0},
    {'k',0,0,0,0,1,1,1},
    {'l',0,0,0,1,1,1,0},
    {'n',0,0,1,0,1,0,1},
    {'o',0,0,1,1,1,0,1},
    {'p',1,1,0,0,1,1,1},
    {'q',1,1,1,0,0,1,1},
    {'r',0,0,0,0,1,0,1},
    {'s',1,0,1,1,0,1,1},
    {'t',0,0,0,1,1,1,1},
    {'u',0,0,1,1,1,0,0},
    {'v',0,0,1,1,1,0,0},
    {'y',0,1,1,1,0,1,1},
    {'z',1,1,0,1,1,0,1},
    {'A',1,1,1,0,1,1,1},
    {'B',1,1,1,1,1,1,1},
    {'C',1,0,0,1,1,1,0},
    {'D',1,1,1,1,1,1,0},
    {'E',1,0,0,1,1,1,1},
    {'F',1,0,0,0,1,1,1},
    {'G',1,0,1,1,1,1,1},
    {'H',0,1,1,0,1,1,1},
    {'I',0,1,1,0,0,0,0},
    {'J',0,1,1,1,0,0,0},
    {'K',0,0,0,0,1,1,1},
    {'L',0,0,0,1,1,1,0},
    {'N',1,1,1,0,1,1,0},
    {'O',1,1,1,1,1,1,0},
    {'P',1,1,0,0,1,1,1},
    {'Q',1,1,1,0,0,1,1},
    {'R',0,0,0,0,1,0,1},
    {'S',1,0,1,1,0,1,1},
    {'T',0,0,0,1,1,1,1},
    {'U',0,1,1,1,1,1,0},
    {'V',0,1,1,1,1,1,0},
    {'Y',0,1,1,1,0,1,1},
    {'Z',1,1,0,1,1,0,1},
    {' ',0,0,0,0,0,0,0},    // space
    {'-',0,0,0,0,0,0,1},    // minus
    {'_',0,0,0,1,0,0,0},    // underscore
    {'~',1,0,0,0,0,0,0},    // upperscore
    {'=',0,0,0,1,0,0,1},    // equal
    {'[',1,0,0,1,1,1,0},    // opening bracket
    {']',1,1,1,1,0,0,0},    // bracket
    {'(',1,0,0,1,1,1,0},    // opening bracket
    {')',1,1,1,1,0,0,0},    // bracket
    {'{',1,0,0,1,1,1,0},    // opening bracket
    {'}',1,1,1,1,0,0,0},    // bracket
    {'^',1,0,0,0,1,1,0},
    {'/',0,1,0,0,1,0,1},    // forward slash
    {'\\',0,0,1,0,0,1,1},   // backward slash
    {'<',0,0,0,1,1,0,1},
    {'>',0,0,1,1,0,0,1},
    {'\'',0,1,0,0,0,0,0},   // quote
    {'"',0,1,0,0,0,1,0},    // double quote
    {'@',1,1,0,0,0,1,1},    // degrees
    {'!',0,1,1,0,1,1,},     // !!
    {0,0,0,0,0,0,0,0}
};

int gpio_seg[]={
    22,                 // sega
    05,                 // segb
    06,                 // segc
    13,                 // segd
    19,                 // sege
    26,                 // segf
    21,                 // segg
    20};                // dp

int gpio_dig[]={
    24,                 // dig1
    25,                 // dig2
    12,                 // dig3
    16};                // dig4

int blink [4][4]={
    {0,0,0,0},              // set, speed, cnt, status
    {0,0,0,0},
    {0,0,0,0},
    {0,0,0,0}
};

#define BLINK_SPEED 200     // default = 200 * 5 = 1000ms = 1s

// holds the value to be displayed/refreshed
// BLANK = nothing to display
char curr_value_dig[4]= {BLANK,BLANK,BLANK,BLANK};
int curr_value_dot[4] = {BLANK,BLANK,BLANK,BLANK};

int gpio_set=0;             // allow only 1 GPIO setup.
int refresh_rate=10;        // default in mS.
int dis_bright=1000;        // default brightness (usec)
long  w_sleep;              // used by psleep())
struct termios oldterm;     // getch() support
int restore_getch;

// indicates that source is being updated and is time critical
// do NOT refresh the display (if might/blink as a result!)
int capture_busy=0;

// number or supported characters
int len = sizeof(disp_char)/sizeof(disp_char[0]);

/*
 * programmed sleep (as normal sleep breaks with itimer())
 * provide the time is in 5ms increments
 * lowest refresh is 5ms  => 200Hz.
 * so if the value of :
 * 20 => 20 x 5 = 100mS
 * 100 => 100 x 5 = 500ms
 * 1000 => 500ms => 5 sec
 */

void psleep(long m_sec_wait)
{
    // adjust counter to keep 5ms in case of slower refresh-rate.
    w_sleep = (m_sec_wait * 5) / refresh_rate ;

    while (w_sleep > 0) usleep(50);
}

/* set blinking a digit
 * digit parameter: number (0 - 3)
 * set parameter:   on = 1 (SET), off = 0 (CLR)
 * speed parameter: 0=default, or value  50 - 300
 *              blinkspeed = value * 5ms  (default 200: 1000ms -> 1s)*/
int set_blink(int digit, int set, int speed)
{
    // digit
    if ((digit < 0) || (digit > 3)) return(1);

    // enable blink ?
    if (set == SET){

        // set speed or default speed
        // normalized in case refresh_rate was adjusted
        if (speed == 0)
            blink[digit][1] = (BLINK_SPEED * 5) / refresh_rate;

        else{
            if ((speed < 50) || (speed > 300)) return(1);

            blink[digit][1] = (speed * 5) / refresh_rate;
        }

        // set cntr
        blink[digit][2] = blink[digit][1];

        // set on
        blink[digit][3] = 1;

        // enable blink
        blink[digit][0] = 1;

    }
    else // disable blink
        blink[digit][0] = 0;

    return(0);
}

/* will set or reset dot on digit */
int set_dot(int digit, int set)
{
    // digit
    if ((digit < 0) || (digit > 3))
        return(1);

    if (set == SET){

        // can not overrule fixed
        if (curr_value_dot[digit] != FIXED)
            curr_value_dot[digit] = SET;
    }
    else if (set == FIXED)
        curr_value_dot[digit] = FIXED;

    else
        curr_value_dot[digit] = BLANK;

    return(0);
}


/* display dot on digit */
void disp_dot(int digit){

    // set digit and dot on
#ifdef _wiring
    digitalWrite(gpio_dig[digit], HIGH);
    digitalWrite(gpio_seg[7], HIGH);
#else
    bcm2835_gpio_write(gpio_dig[digit],HIGH);
    bcm2835_gpio_write(gpio_seg[7],HIGH);
#endif
    // determine brightness
    usleep(dis_bright);

    // de-select digit and dot
#ifdef _wiring
    digitalWrite(gpio_dig[digit], LOW);
    digitalWrite(gpio_seg[7], LOW);
#else
    bcm2835_gpio_write(gpio_dig[digit],LOW);
    bcm2835_gpio_write(gpio_seg[7],LOW);
#endif
}

/* flash dot at start and end
 *  @dir : direction for display dots
 */
void flash_dot(int dir)
{
    int lp;

    // set start digit
    if (dir == LEFT)   set_dot(3,SET);
    else set_dot(0,SET);
    psleep(80);

    // move and move out (hence 5)
    for (lp= 0; lp < 5; lp++ ){
        move_digits(0,3,dir,BLANK);
        psleep(80);
    }

}

/* will perform exit.
 * paramter : flsh will display flashing dots*/

void do_exit(int flsh){
    int lp;

    // in case update was blocked
    capture_busy=0;

    // set dots and digit off
    for(lp = 0; lp < 4; lp++){
        curr_value_dot[lp] = BLANK;
        curr_value_dig[lp] = BLANK;
    }

    // set the leds +dp off (to be sure)
    for(lp = 0; lp < 8; lp++)
#ifdef _wiring
        digitalWrite(gpio_seg[lp],LOW);
#else
        bcm2835_gpio_write(gpio_seg[lp],LOW);
#endif
    // display closing dots
    if (flsh == SET)  flash_dot(LEFT);

    // clear refresh timer
    stop_timer();

    // short break for timer to stop
    usleep(dis_bright);

    // restore keyboard (if interrupted during get_ch())
    if (restore_getch)
    {
        if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){ // Restore the old settings.
            perror("tcsetattr() error ");
            puts("Attempting to recover old settings.");

            if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){
                perror("tcsetattr() error ");
                puts("Gave up...\nI suggest you restart your terminal -- old settings were not restored.");
            }
        }
    }
}

/* setup hardware and program in the right way */

void do_init(int sig)
{
    int lp;
    struct sigaction act;

    if (gpio_set == 0){     // setup for GPIO (ONCE !)
#ifdef _wiring
        wiringPiSetupGpio();
#else
        bcm2835_init();
#endif
        gpio_set = 1;
    }

    // sets segments and dot low
    for (lp=0; lp < 8; lp++)
    {
#ifdef _wiring
           pinMode(gpio_seg[lp],OUTPUT);
           digitalWrite(gpio_seg[lp],LOW);
#else
            bcm2835_gpio_fsel(gpio_seg[lp], BCM2835_GPIO_FSEL_OUTP);
            bcm2835_gpio_write(gpio_seg[lp],LOW);
#endif
    }

    // set digits low
    for (lp=0; lp < 4; lp++)
    {
#ifdef _wiring
            pinMode(gpio_dig[lp],OUTPUT);
            digitalWrite(gpio_dig[lp],LOW);
#else
            bcm2835_gpio_fsel(gpio_dig[lp], BCM2835_GPIO_FSEL_OUTP);
            bcm2835_gpio_write(gpio_dig[lp],LOW);
#endif
    }

    // setup signals for cntrl-c (if requested)
    if (sig == CTRLC){
        memset(&act, '\0',sizeof(act));
        act.sa_handler = &signal_handler;
        sigemptyset(&act.sa_mask);

        sigaction(SIGTERM,&act, NULL);
        sigaction(SIGINT,&act, NULL);
        sigaction(SIGABRT,&act, NULL);
    }
    // set refreshtimer
    if (start_timer(refresh_rate, &refresh_disp))
    {
        printf("\ntimer error\n");
        do_exit(0);
        exit(1);
    }
}


/* perform a test on a digit */
int do_selftest(int digit)
{
    char val1[10]={'0','1','2','3','4','5','6','7','8','9'};
    char val2[10]={'a','b','c','d','e','f','g','h','i','j'};
    int num;
    char buf[30];

    // digit check digit
    if ((digit < 0) || (digit > 3))
        return(1);

    sprintf(buf,"*** Test on digit: %d ***\n",digit);
    printf(YLWSTR,buf);

    // do init
    do_init(CTRLC);

    // dot (dp) test
    printf(YLWSTR,"Set Dot\n");
    set_dot(digit,SET);

    printf("ON \r");
    fflush(stdout);
    psleep(100);

    set_dot(digit,CLR);

    printf("OFF \r");

    // set individual leds on (Common Cathode)
    printf(YLWSTR,"Segments test\n");

    // select digit
#ifdef _wiring
    digitalWrite(gpio_dig[digit],HIGH);
#else
    bcm2835_gpio_write(gpio_dig[digit],HIGH);
#endif
    for (num = 0; num < 7; num++)
    {
            printf("segment %d \r", num);
            fflush(stdout);
#ifdef _wiring
            digitalWrite(gpio_seg[num],HIGH);
            psleep(50);
            digitalWrite(gpio_seg[num],LOW);

            // de-select digit
            digitalWrite(gpio_dig[digit],LOW);
#else
            bcm2835_gpio_write(gpio_seg[num],HIGH);
            psleep(50);
            bcm2835_gpio_write(gpio_seg[num],LOW);

            // de-select digit
            bcm2835_gpio_write(gpio_dig[digit],LOW);
#endif
    }

    // display numbers
    printf(YLWSTR,"Display numbers (0 - 9)\n");
    for(num = 0; num < 10; num++)
    {
        printf(" Now display character %c \r",val1[num]);
        fflush(stdout);
        set_char(digit,val1[num]);
        psleep(100);
    }

    // display characters
    printf(YLWSTR,"Display alpha characters (a - j)\n");
    for(num = 0; num < 10; num++)
    {
        printf(" Now display character %c \r",val2[num]);
        fflush(stdout);

        set_char(digit,val2[num]);
        psleep(100);
    }

    printf(YLWSTR,"*** self test finished ***\n");
    clr_digit(digit);
    return(0);
}

/* Display a value on a specific led
 * usleep must be used as the refresh time
 */
void disp_digit(int digit, char value)
{
    int val, lp;

    // check character is supported
    // len = number of supported characters
    // this COULD be removed as we check already at set_char
    // maybe later (if needed to get 10usec)
    for (val = 0; val < len; val++){

        if (disp_char[val][0] == value)
            break;
    }

    //if not found (should never happen..), only return if dot is not set
    if (val == len) {
        if (curr_value_dot[digit] == BLANK)
            return;
    }

    if (blink[digit][0] == 1)       // blink set ?
    {
        if (blink[digit][3] == 0)   // is off?
        {
            if (blink[digit][2]-- > 0){ // timer expired?

                // if dot was set FIXED
                if (curr_value_dot[lp] == FIXED)
                    disp_dot(digit);

                return;
            }
                                    // reset speed
            blink[digit][2] = blink[digit][1];
            blink[digit][3] = 1;    // set as on
        }
        else{

            if (blink[digit][2]-- <= 0) // timer expired?
            {
                                     // reset speed
                blink[digit][2] = blink[digit][1];
                blink[digit][3] = 0;  // set as off
            }
        }
    }
    // select digit
#ifdef _wiring
    digitalWrite(gpio_dig[digit],HIGH);
#else
    bcm2835_gpio_write(gpio_dig[digit],HIGH);
#endif

    // if digitalPoint
    if (curr_value_dot[digit] != BLANK)
#ifdef _wiring
           digitalWrite(gpio_seg[7], HIGH);
#else
           bcm2835_gpio_write(gpio_seg[7],HIGH);
#endif
    // if valid character to display
    if (val != len)
    {
        // set the leds on (Common Cathode)
        for(lp = 1; lp < 8; lp++)
        {
            if (disp_char[val][lp] == 1)
#ifdef _wiring
                digitalWrite(gpio_seg[lp-1],HIGH);
#else
                bcm2835_gpio_write(gpio_seg[lp-1],HIGH);
#endif
        }
    }

    // the longer the sleep the brighter the display
    usleep(dis_bright);

    // de-select digit
#ifdef _wiring
    digitalWrite(gpio_dig[digit],LOW);
#else
    bcm2835_gpio_write(gpio_dig[digit],LOW);
#endif

    // set the leds off (to prevent glitter on next)
    for(lp = 0; lp < 7; lp++){
#ifdef _wiring
        digitalWrite(gpio_seg[lp],LOW);
#else
        bcm2835_gpio_write(gpio_seg[lp],LOW);
#endif

    }
    //de-select dot (even if NOT set- this code is faster)
#ifdef _wiring
    digitalWrite(gpio_seg[7], LOW);
#else
    bcm2835_gpio_write(gpio_seg[7],LOW);
#endif

}

/* sets a character on certain display */

int set_char (int digit, char val){

    int lp;

    // digit check digit
    if ((digit < 0) || (digit > 3))
        return(1);

    // check character is supported
    for (lp = 0; lp < len; lp++){

        if (disp_char[lp][0] == val){
            break;
        }
    }

    // if not supported
    if (lp == len){
        // is dot ?
        if (val == '.') return(set_dot(digit,SET));
        else return(1);
    }

    curr_value_dig[digit] = val;

    return(0);
}

/* clears display value on a digit */

int clr_digit (int digit){

    // digit check digit
    if ((digit < 0) || (digit > 3))
        return(1);

    curr_value_dig[digit] = BLANK;

    return(0);
}

/* sets to display a numeric value on the leds
 * value is maximum 4 digits/bytes
 */

int set_value (int num){

    int lp = 0, dd, len = 1;
    char buff[6];

    dd = num;

    //determine # digits (max is 4)
    while(dd > 9){
        dd = dd / 10;
        len++;
    }

    if (len > 4) return(1);

    sprintf(buff,"%04d\0",num);

    for(lp = 0; lp < 4; lp++){

        curr_value_dig[lp] = buff[lp];

        // printf("value digit %d, %x\n",lp,curr_value_dig[lp]);
    }

    return(0);
}

/* update refresh time. value in ms */
int set_refresh( int rate){
    if ((rate < 5) || (rate > 100)) return(1);

    // refresh time takes ~4.8ms on brightlevel 1000
    // increasing the refresh with larger bright could interrupt refresh routine
    // this is adjusted (if needed).

    if (refresh_rate == 5)
        if (dis_bright > 1000) dis_bright = 1000;

    refresh_rate = rate;
    return(update_timer(rate));
}

/* adjust brightness time. value in usec */
int set_brightness(int bright){

    if ((bright < 5) || (bright > 2000)) return(1);

    // refresh time is ~4.8ms on bright 1000
    // increasing the brightness on 5ms refresh would interrupt refresh routine

    if (refresh_rate == 5)
        if (bright > 1000)  return(1);

    dis_bright = bright;

    return(0);

}

/* called as timer expires */
void refresh_disp(void)
{
    int lp;

    // to MEASURE AND DISPLAY refresh time :
    // uncomment next 4 lines (also see at end of refresh_dip)
    //struct timeval tv;
    //unsigned long  st;
    //gettimeofday(&tv,NULL);
    //st =  tv.tv_usec;

    // count-down psleep
    if (w_sleep > 0)  w_sleep--;

    // return if capture of time critical data is busy
    if (capture_busy)   return;


    // refresh digit and dots (if set)
    for (lp = 0; lp < 4; lp++)
    {
        if (curr_value_dig[lp] != BLANK)
                disp_digit(lp,curr_value_dig[lp]);

        // display dot through disp-digit to support blink
        else if (curr_value_dot[lp] != BLANK)
                disp_digit(lp,'.');
    }

    // to MEASURE AND DISPLAY refresh time :
    // uncomment next 2 lines (also see at begin of refresh_dip)
    //gettimeofday(&tv,NULL);
    //printf("refresh_disp it took %d\n", (tv.tv_usec -st));

}

/* swap digit contents between digits */
int swap_digit(int s_digit, int d_digit)
{
    int store;
    // digit check digit
    if ((s_digit < 0) || (s_digit > 3))
        return(1);

    // digit check digit
    if ((d_digit < 0) || (d_digit > 3))
        return(1);

    store = curr_value_dig[d_digit];

    curr_value_dig[d_digit] = curr_value_dig[s_digit];

    curr_value_dig[s_digit] = store;

    return(0);
}

/* move digit contents between digits
 * s_digit: left digit (0-3)
 * e_digit: right digit (0-3)
 * direction: 1 =>>>> RIGHT, 0 = <<<<<<= LEFT
 * rotate : 1 = ROTATE digit, 0 = BLANK out last digit
 */

int move_digits(int s_digit, int e_digit, int direction, int rotate)
{
    int  lp, save,dot;

    // digit check digit
    if ((s_digit < 0) || (s_digit > 3))
        return(1);

    // digit check digit
    if ((e_digit < 0) || (e_digit > 3))
        return(1);

    // left digit can not be lower or same as right digit
    if (s_digit >= e_digit) return(1);

    if (direction == LEFT){          // <==== left

        // save start value
        save = curr_value_dig[s_digit];
        dot = curr_value_dot[s_digit];

        lp=s_digit;

        // move digit left
        while (lp < e_digit){
            curr_value_dig[lp] = curr_value_dig[lp+1];

            // Dot NOT fixed
            if (curr_value_dot[lp+1] != FIXED){
                curr_value_dot[lp] = curr_value_dot[lp+1];
            }
            lp++;
        }

        if(rotate == ROTATE){
            curr_value_dig[e_digit] = save;      // rotate
            if (curr_value_dot[e_digit] != FIXED)
                curr_value_dot[e_digit]= dot;
        }
        else {
            curr_value_dig[e_digit] = BLANK;      //blank
            if (curr_value_dot[e_digit] != FIXED)
                curr_value_dot[e_digit]= BLANK;
        }
    }
    else                        // =======> right
    {
        // save start value
        save = curr_value_dig[e_digit];
        dot = curr_value_dot[e_digit];
        lp=e_digit;

        // move digit right
        while (lp > s_digit){
            curr_value_dig[lp] = curr_value_dig[lp-1];

            // Dot NOT fixed
            if (curr_value_dot[lp+1] != FIXED)
                curr_value_dot[lp] = curr_value_dot[lp-1];

            lp--;
        }
        if(rotate == ROTATE)
        {
            curr_value_dig[s_digit] = save;      // rotate
            if (curr_value_dot[s_digit] != FIXED)
                curr_value_dot[s_digit] = dot;
        }
        else
        {
            curr_value_dig[s_digit] = BLANK;      //blank
            if (curr_value_dot[s_digit] != FIXED)
                curr_value_dot[s_digit] = BLANK;
        }
    }

    return(0);
}

 /* Reads up to max characters into buffer.
  * Skips interrupted getchar() call by the itimer
  * Returns number of characters in buffer (terminated with \0)
  */
int get_line(char buf[], int max)
{   int len=0;
    char c;

    while(len < max){
        while ((c=getchar()) == 0xff);    // loop to get value character
        if (c == '\n') break;
        buf[len++]=c;
    }

    buf[len]='\0';
    return(len);
}

/* getch(), gets a single character at a time without a return nor display.
 * returns read character if successful.
 * returns -1 on non-fatal error.
 * returns -2 on fatal error.
 */
char get_ch()
{
    struct termios newterm;
    char    buf;

    if(tcgetattr(STDIN_FILENO, &newterm) < 0)
    {
          // Get the old settings to modify
          perror("tcgetattr() error ");
          return -1;
    }

    oldterm = newterm;
    newterm.c_lflag    &= ~(ECHO | ICANON);               // Turn off echo and canonical mode (this is what makes it not wait for a newline)
    newterm.c_cc[VMIN]  = 1;                              // Set the amount of characters to get to 1
    newterm.c_cc[VTIME] = 0;                              // No timeout on waiting for the character
    if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &newterm) < 0){ // Flush the buffer (TCSAFLUSH), then set the new terminal settings.
           perror("tcsetattr() error ");
           return -1;
    }

    restore_getch = 1;

    buf = 0xff;
    while( buf == 0xff)
        buf = fgetc(stdin);                              // Here is the getc() you've been waiting for!


    if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){ // Restore the old settings.
        ///perror("tcsetattr() error ");
        //puts("Attempting to recover old settings.");

        if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){
            //perror("tcsetattr() error ");
            //puts("Gave up...\nI suggest you restart your terminal -- old settings were not restored.");
            return -2;
        }
    }

    restore_getch = 0;

    return buf;
}


/*
 * read character from keyboard
 * Skips interrupted getch() call by the itimer
 */
char get_char()
{
    char c;

    while (1){
       c=getchar();

       if (c != 0xff)    // loop to get value character
            return(c);
    }
}

void signal_handler(int sig_num)
{
    switch(sig_num)
    {

    case SIGABRT:
    case SIGINT:
    case SIGTERM:
        printf(GRNSTR,"\nstopping led\n");
        do_exit(1);
        exit(0);
        break;

    }
}
