#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "hs42led.h"


/* set the numeric value to display */
int get_value()
{
    int lp, num1=0, num = 0xff;
    char ch;
    char buf[10]={};

    printf(REDSTR,"Welcome to get_value\n");

    while(1){

        printf(YLWSTR,"Enter a numeric value of 4 digits. (! = exit)\n");

        while (num == 0xff){

            if (get_line(buf,4) != 4) {

                if (buf[0] == '!') {
                    printf(REDSTR,"Returning from get_value\n");
                    return;
                }

                if (buf[0] == 0x0) continue;

                printf ("Need 4 digits\n");
                continue;
            }

            for (lp = 0; lp < 4 ;lp++){

                if (buf[lp] == '!') return;

                // check on numeric value
                num1 = (int) buf[lp] - '0';
                if ((num1 < 0) || (num1 > 9))
                    break;
            }

            if (lp == 4)   num = atoi(buf);
            else printf ("Invalid number\n");
        }

        printf ("Now on display : %04d\n",num);
        set_value(num);

        num = 0xff;

    }

}


/* wobble the display content 15 times */

void wobble(int value)
{
    int num=0, digit=0, dir =1;
    printf(REDSTR,"Welcome to wobble\n");
    // set initiale value
    set_value(value);

    while (num < 15)
    {
        move_digits(2,3,RIGHT,ROTATE);
        move_digits(0,1,LEFT,ROTATE);
        swap_digit(0,3);

        // 50 = speed (50 x 5ms = 250ms = 1/4 second)
        set_blink(digit,SET,50);

        // 0 = default speed
        if (digit == 0){
             set_blink(4,CLR,0);
             dir = 1;
         }
        else set_blink(digit-1,CLR,0);

        if (digit == 3) dir = -1;

        digit = digit + dir;

        // 300 x 5ms = 1.5s
        psleep(400);
        num++;
    }
}

/*
 * display a string moving the digits
 * string = string to display
 * len = length of the string
 * speed= how fast to move.( * 5ms )
 * dir = direction (RIGHT of LEFT)
 */
void display_string( char buf[], int len, int speed, int dir)
{
    int lp=0, digit;

    // set start digit
    if (dir == LEFT)    digit = 3;
    else digit = 0;

    for (lp= 0; lp < len; lp++ ){

        // set dot
        if (buf[lp] == '.')  set_dot(digit,SET);

        else {

            if (move_digits(0,3,dir,BLANK))
                 printf("problem with moving\n");

            else if (set_char(digit,buf[lp])){
                set_char(digit,'-');        // non-supported character
            }

            psleep(speed);
        }

    }

    for (lp = 0;lp < 4;lp++) {
       psleep(speed);
       move_digits(0,3,LEFT,BLANK);
    }
}

/* display a pre-initialised string */
void test_string()
{
    char val1[]="....THIS IS A TEST STRING - 0123456789 - BY SEE YOU !! ";

    printf(REDSTR,"Welcome to test_line\n");

    // speed is 100 x 5ms = 500ms = 0.5s
    display_string(val1, sizeof(val1), 100, LEFT);
}

/* get your input and display that is display on moving display*/
void test_line()
{
    char buf[40];
    char ch;
    int len;

    printf(REDSTR,"Welcome to test_line\n");

    while(1){
        printf("Enter a line (max. 40 characters) exit = enter\n");
        len = get_line(buf, sizeof(buf));
        if (len == 0) break;
        display_string(buf,len,100, LEFT);

    }

    printf("done\n");
}

/* display character (AFTER ENTER) from keyboard,
 * dir = where to move current character.. LEFT or RIGHT
 * dir = FIXED no move overwrite digit
 */

void test_char(int dir)
{
    char c,rem_dot=0, digit=0x0ff;

    printf(REDSTR,"Welcome to test_char\n");

    // set start digit
    if (dir == FIXED)

        while (digit == 0xff){
            printf(YLWSTR,"On which display do you want to display ? (! = exit)");
            c=get_char();

            if ((c=='0') ||(c=='1') || (c=='2')||(c=='3')){
                digit = c - '0';
                printf("Using display %c\n",c);
            }

            else if (c == '!')  return;

            else
                printf(REDSTR,"Invalid display\n");
        }

    else if (dir == LEFT)    digit = 3;
    else digit = 0;

    while(1){
        printf(GRNSTR,"Give character and press <enter>. (! = exit) ");

        if ((c = get_char()) != '\n' ){

            // debug only
            printf("This character received 0x%x %c\n",c,c);

            if (c ==  '.'){ // toggle dot

                if (rem_dot) {
                    set_dot(digit,CLR);
                    rem_dot=0;
                }
                else{
                    set_dot(digit,SET);
                    rem_dot=1;
                }
            }
            else if (c  == '!')
                break;

            else {
                if (dir != FIXED)
                    move_digits(0,3,dir,BLANK);

                if (set_char(digit,c))
                    set_char(digit,'-');
            }
        }

        else  // debug only
            printf(BLUSTR, "new line character received \n");
    }

    printf("Test_char done\n");
}


/* display character (WITHOUT enter) from keyboard,
 * dir = where to move current character.. LEFT or RIGHT
 * dir = FIXED no move overwrite digit
 */

void test_ch(int dir)
{
    char c,rem_dot=0, digit=0xff;

    printf(REDSTR,"Welcome to test_ch\n");

    // set start digit
    if (dir == FIXED)

        while (digit == 0xff){
            printf(YLWSTR,"On which display do you want to display ? (! = exit) ");
            c=get_ch();

            if ((c=='0') ||(c=='1') || (c=='2')||(c=='3')){
                digit = c - '0';
                printf("\nUsing display %c\n",c);
            }

            else if (c == '!')  return;

            else
                printf(REDSTR,"\nInvalid display\n");
        }

    else if (dir == LEFT)    digit = 3;
    else digit = 0;

    while(1){
        printf(GRNSTR, "Enter character (! = done)\n");

        if ((c = get_ch()) != '\n' ){
            // debug only
            printf("This character was received 0x%x %c\n",c,c);

            if (c ==  '.'){    // toggle dot

                if (rem_dot) {
                    set_dot(digit,CLR);
                    rem_dot=0;
                }
                else{
                    set_dot(digit,SET);
                    rem_dot=1;
                }
            }

            else if (c  == '!')
                break;

            else{
                if (dir != FIXED) move_digits(0,3,dir,BLANK);

                if (set_char(digit,c))
                    set_char(digit,'-');
            }
        }

        else  // debug only
            printf("new line character was received. Not needed !!!\n");
    }

    printf("test_ch done\n");
}


int main(int argc, char *argv[]) {

#ifdef _wiring
    printf("using wiringPi library\n");
#else
    printf("using BCM2835 library\n");
#endif

    /* initialise and set control-c on.*/
    // MUST ALWAYS BE DONE FIRST !!
    do_init(CTRLC);

    /* Set brightness higher */
    //set_brightness(1500);

    /* move dot to last digit (e.g. to show init was done)*/
    flash_dot(RIGHT);

    /* set blink digit 0 with default speed (200)  */
    //set_blink(0, SET, 0);

    /* set blink digit 1 with speed 300 */
    //set_blink(1, SET, 300);

    /* set blink digit 2 with speed 100*/
    //set_blink(2, SET, 100);

    /* set blink digit 3 with default speed (200) */
    //set_blink(3, SET, 0);

    /* set dot on digit 3 FIXED (will not move with move_digits()*/
    //set_dot(0,FIXED);

    /* get keyboard line input and display on move display*/
    test_line();

    /* keyboard character (waiting for enter) */
    //test_char(LEFT);

    /* keyboard character (waiting for enter)on fixed digit*/
    //test_char(FIXED);

    /* keyboard character on moving display*/
    //test_ch(LEFT);

    /* keyboard character on fixed digit*/
    //test_ch(FIXED);

    /* wobble the value over the digits */
    //wobble(1234);

    /* get a number value and display */
    //get_value();

    /* do a self_test on digit0 */
    //do_selftest (1);

    /* display a buffer of test moving over the display */
    //test_string();

    /* ALWAYS PERFORM do_exit at the end */
    do_exit(1);

}
