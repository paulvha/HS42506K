/* supports display on HS420561K-32
 *
 * version 1.0 / paulvha / march 2016
 ****************************************************************************
 * The following characters are supported:
 *  0 - 9 (numbers)
 *  a - z (except m,w,x)    some will display upper case
 *  A - Z (except M,W,X)    some will display lower case
 *  special characters / signs :
 *        space
 *      - minus
 *      _ underscore
 *      ~ upperscore
 *      ( [ { opening brackets
 *      ) ] } closing brackets
 *      < less than
 *      > greater than
 *      ^ to the power off
 *      \ backward slash
 *      / forward slash
 *      @ degree symbol
 *      ' quote
 *      " double quote
 *      = equal
 *      ! exclamation mark
 ****************************************************************************
 *
 * HARDWARE SETUP :
 *
 * display      40-pin      GPIO    Abbreviation
 * ---------------------------------------------
 * 12           18          24          dig1
 * 11           15          22      segA
 * 10           37          26      sefF
 * 9            22          25          dig2
 * 8            32          12          dig3
 * 7            29          5       segB
 * 6            36          16          dig4
 * 5            40          21      segG
 * 4            31          6       segC
 * 3            38          20      dp
 * 2            33          13      segD
 * 1            35          19      segE
 *
 *
 ****************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 ***************************************************************************
 *
 * This version of GPL is at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 *
 */

// use wiringPi as alternative to BCM2835
// this can be provided also with -D_wiring with  gcc.
//#define _wiring

// color display
#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"

// to be used as parameters in the calls
#define LEFT  0
#define RIGHT 1
#define ROTATE 1
#define BLANK 0x0
#define CTRLC 1
#define SET 1
#define CLR 0
#define FIXED 2

// indicates that source is being updated
// refresh_disp will return
// should not take more than 10ms
int capture_busy;

/* MUST be called first to setup the GPIO
 * parameter 1 (CTRLC)= will setup for control-c handling
 */
void do_init(int set);

/* flash the dots,
 * parameter 1: left to right (LEFT)
 * else right to left (RIGHT) */
void flash_dot(int dir);

/* set/clear a dot on a digit,
 * first parameter:     digit (0 -3)
 * second parameter:    1 = set (SET), 0 = clear dot(CLR)*/
int set_dot (int digit, int set);

/* set a character on a digit
 * int = digit ( 0 -3 )
 * char = supported char (see heading)
 * return 0 = OK, 1 = character not supported */
int set_char (int digit, char value);

/* set a number value on the digits,
 * parameter =  sets numeric value on the leds to display
 * value is maximum 4 digits/bytes */
int set_value (int value);

/* clears a value from a digit
 * int = digit ( 0 - 3 )
 * return 0 = OK, 1 = invalid digit*/
int clr_digit (int digit);

/* set refresh rate in milliseconds.
 * Can be value between 5 and 100. Default is 10.
 * Brightness level will be maximum 1000 at refresh 5.
 * return 0 = OK, 1 = invalid value (ignored) */
int set_refresh(int refresh);

/* set the brightness (on-time of leds).
 * value can be between 5 and 2000 Usec
 * Default is 1000.
 * if refresh = 5, the maximum value is 1000.
 * return 0 = OK, 1 = invalid value */
int set_brightness(int bright);

/* set blinking a digit
 * parameter: digit number (0 - 3)
 * parameter:  set on = 1 (SET), off = 0 (CLR)
 * speed parameter: 0=default, or value  50 - 300
 *              blinkspeed = value * 5ms  (default 200: 1000ms -> 1s)*/
int set_blink(int digit, int set, int speed);

/* move digit contents between digits
 * s_digit: left digit (0-3)
 * e_digit: right digit (0-3)
 * direction: 1 =>>>> right (RIGHT), 0 = <<<<<<= left (LEFT)
 * rotate : 1 = rotate digit (ROTATE), 0 = blank out last digit
 * setting blank, will cause that after 3 rounds the display is empty */
int move_digits(int s_digit, int e_digit, int direction, int rotate);

/* swap contents between digits
 *  s_digit: digit (0-3)
 *  d_digit: digit (0-3) */
int swap_digit(int s_digit, int d_digit);

/* must be called to close the GPIO's' correctly
 * parameter = 1 (SET): will flash dot right to left */
void do_exit(int flsh);

/* will perform a test on a digit
 * parameter = digit number (0 - 3)
 * Will test the dot, count from 0 -> 9 and a - j characters. */
int do_selftest(int digit);

/* as sleep() function seems to collite with setitimer()
 * psleep can be used to count down
 * value * 5ms = sleeptime */
void psleep(long value);

/* will read character from keyboard handling itimer interrupts */
char get_char();

/* will read a line from the keyboard in a buffer handling itimer
 * interrupts
 * buf = buffert to store line
 * max = maximum characters to read
 * will return the length of the characters in buffer
 * buffer will be terminated with \0.
 * Either when enter was pressed or max was reached. */
int get_line(char buf[], int max);

/*********** supporting routines ************/
/**** not mend for user level usages ********/

/* will refresh display of the digits and dots. The refresh time can
 * be set with set_refresh. Default 10ms (100hz) */
void refresh_disp(void);

/* Display ONE time certain character on display
 * int = digit
 * char = number to display
 * used by refresh_disp() to set a value permanent use set_char */
void disp_digit(int digit, char value );

/* Display ONE time a dot on a digit
 * int = digit
 * used by refresh_disp() to set a dot permanent use set-dot */
void disp_dot(int digit);

/* signal handler in case control-c was requested with do-init() */
void signal_handler(int sig_num);
